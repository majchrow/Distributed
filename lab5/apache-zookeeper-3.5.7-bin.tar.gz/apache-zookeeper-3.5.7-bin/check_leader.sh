#!/bin/bash

for i in {1..3}; do 
	echo "218${i}"
	echo srvr | nc localhost 218${i} | grep Mode
done
