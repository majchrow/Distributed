#!/bin/bash

./bin/zkCli.sh -server 127.0.0.1:2181