#!/bin/bash

for i in {1..3}; do 
	sudo ./bin/zkServer.sh --config conf${i} stop 
done
